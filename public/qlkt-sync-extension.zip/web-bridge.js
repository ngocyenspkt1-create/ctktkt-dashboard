(() => {
  if (!/^\/ppa-heat-rate\/?$/.test(window.location.pathname)) return;
  const channel = "ctktkt-qlkt-sync";
  const post = message => window.postMessage({ channel, sender: "ctktkt-extension", ...message }, window.location.origin);

  window.addEventListener("message", async event => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const message = event.data;
    if (!message || message.channel !== channel || message.sender !== "ctktkt-web") return;
    if (message.type === "PING") {
      post({ type: "READY", version: chrome.runtime.getManifest().version });
      return;
    }
    if (message.type !== "SYNC_PPA" || !/^\d{4}-\d{2}-\d{2}$/.test(String(message.operatingDate || ""))) return;
    try {
      const result = await chrome.runtime.sendMessage({ type: "SYNC_PPA_QLKT", operatingDate: message.operatingDate });
      post({ type: "SYNC_PPA_RESULT", requestId: message.requestId, result });
    } catch (error) {
      post({ type: "SYNC_PPA_RESULT", requestId: message.requestId, result: { ok: false, error: error instanceof Error ? error.message : "Không kết nối được với tiện ích QLKT." } });
    }
  });

  post({ type: "READY", version: chrome.runtime.getManifest().version });
})();
